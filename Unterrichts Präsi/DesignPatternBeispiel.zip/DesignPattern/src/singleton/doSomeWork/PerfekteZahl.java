package singleton.doSomeWork;

import singleton.singleton.Protokoll;

public class PerfekteZahl {
	
	public PerfekteZahl(){}
	
	public void getPerfekteZahlen(){
		// Variablendeklaration
		long ergebnis, zahl = 1;
		Protokoll p = Protokoll.getInstance();

		// Verarbeitung & Ausgabe 
		while (true)
		{
			// Zahl erh�hen
			zahl++;
			ergebnis = 0;
			// Teiler suchen und Teilerergebnis bestimmten
			for (long i = 1; i < zahl; i++)
			{
				if (zahl % i == 0) ergebnis += i;
			}
			// Wenn zahl gleich dem Teilerergebnis ist, Ausgabe
			if (ergebnis == zahl){
				p.log("Perfekte Zahl: " + zahl);
				System.out.println("Perfekte Zahl: " + zahl);
			}

			// Unendliche Laufzeit h�tte eine Fehlermeldung zur Folge
			// Abbruch, wenn Datentyp Bereich ersch�pft
			if (zahl == Long.MAX_VALUE) break;
		}
	}
	public static void main(String[] args){
		PerfekteZahl perf = new PerfekteZahl();
		perf.getPerfekteZahlen();
	}
}
