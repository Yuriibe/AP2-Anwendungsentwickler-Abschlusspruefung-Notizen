package singleton.doSomeWork;

import singleton.singleton.Protokoll;

public class LogB {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Protokoll p = Protokoll.getInstance();
		for(int i = 0; i < 100; i++){
			p.log("B " + i);
			try {
				Thread.sleep(100);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

}
