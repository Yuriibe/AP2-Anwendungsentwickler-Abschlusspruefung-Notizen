package singleton.doSomeWork;

import singleton.singleton.Protokoll;

public class Primzahl {
	
	long startzahl;
	
	public Primzahl(){
		this.startzahl = 1;
	}
	
	public Primzahl(long startzahl){
		this.startzahl = startzahl;
	}
	
	public void generierePrimzahlen(){
		Protokoll p = Protokoll.getInstance();
		for(long i = startzahl; i < Long.MAX_VALUE; i++){
			
			 boolean hatTeiler = false;

		     //Schleife f�r die Teiler
		     for (int teiler = 2; (teiler < i /2) && !hatTeiler; teiler++){
		       //Pr�fen ob teiler die testzahl Ganzzahlig teilt
		       if (i % teiler == 0) hatTeiler = true;
		     }
		      
		     //Ausgabe ob die Zahl eine Primzahl ist
		     if(!hatTeiler) p.log("Primzahl: " + i);
		}
	}
	
	public static void main(String[] args){
		Primzahl prim = new Primzahl(10000000L);
		prim.generierePrimzahlen();
	}
}
