package singleton.singleton;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class Protokoll {
	private static Protokoll instance;
	private File logFile;
	private FileWriter fw;
	private BufferedWriter bw;

	public File getLogFile() {
		return logFile;
	}

	public void setLogFile(File logFile) {
		this.logFile = logFile;
	}

	private Protokoll() {
		logFile = new File("Protokoll.txt");
		try {
			fw = new FileWriter(this.getLogFile(), true);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		bw = new BufferedWriter(fw);
	}

	public static Protokoll getInstance() {
		if (Protokoll.instance == null)
			instance = new Protokoll();
		return instance;
	}

	public void log(String text) {
		try {
			bw.append(text);
			bw.newLine();
			bw.flush();
		} catch (ArrayIndexOutOfBoundsException aioobe) {
			System.out.println("aioobe");
		} catch (IOException ioe) {
			System.out.println("Habe gefangen: " + ioe);
		}
	}

}
