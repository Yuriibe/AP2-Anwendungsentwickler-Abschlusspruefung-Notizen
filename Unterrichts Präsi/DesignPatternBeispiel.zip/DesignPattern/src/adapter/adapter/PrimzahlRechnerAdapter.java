package adapter.adapter;

import adapter.fremdeFirma.v1.IPrimzahl;

public class PrimzahlRechnerAdapter implements IPrimzahl {

	adapter.fremdeFirma.v5411.IPrimzahl pzm = new adapter.fremdeFirma.v5411.PrimzahlRechner();
	
	@Override
	public boolean isPrimzahl(long zahl) {
		return pzm.isPrimzahl(zahl);
	}

	@Override
	public boolean[][] primzahlfeld(long startwert) {
		boolean[] primzahlen = pzm.primzahlfeld(startwert, 10000);
		boolean[][] ergebnis = new boolean[100][100]; 
		int index = 0;
		for(int y = 0; y < 100; y++){
			for(int x = 0; x < 100; x++){
				ergebnis[x][y] = primzahlen[index++];
			}
		}
		return ergebnis;
	}

}
