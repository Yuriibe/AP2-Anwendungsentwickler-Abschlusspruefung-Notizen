package adapter.eigeneFirma;

import adapter.adapter.PrimzahlRechnerAdapter;

public class PrimzahlmatrixStart {

	public static void main(String[] args){
		  new Primzahlmatrix("Primzahlmatrix", new PrimzahlRechnerAdapter());
	  }
	  

}
