package adapter.eigeneFirma;

import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Insets;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.WindowConstants;

import adapter.fremdeFirma.v1.IPrimzahl;

/**
  *
  * Mathe kann sch�n sein
  *
  * @version 1.0 vom 26.05.2011
  * @author Tenbusch
  */

public class Primzahlmatrix extends JFrame {

  // Anfang Attribute
  private static final long serialVersionUID = 1L;
  private JPanel[][] pnlHintergrund = new JPanel[100][100];
  private JLabel lblBeschriftung = new JLabel();
  private JTextField nfdEingabefenster = new JTextField();
  private JButton btnBerechne = new JButton();
  private IPrimzahl pzt;
  // Ende Attribute

  public Primzahlmatrix(String title, IPrimzahl pzt) {
    // Frame-Initialisierung
    super(title);
    setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
    int frameWidth = 900;
    int frameHeight = 900;
    setSize(frameWidth, frameHeight);
    Dimension d = Toolkit.getDefaultToolkit().getScreenSize();
    int x = (d.width - getSize().width) / 2;
    int y = (d.height - getSize().height) / 2;
    setLocation(x, y);
    Container cp = getContentPane();
    cp.setLayout(null);
    // Anfang Komponenten
    this.pzt = pzt;
    boolean[][] primmatrix = pzt.primzahlfeld(1L);
    for(int xx = 0; xx < 100; xx++){
      for(int yy = 0; yy < 100; yy++){
        this.pnlHintergrund[xx][yy] = new JPanel(null);
        this.pnlHintergrund[xx][yy].setBounds(50 + xx*8, 50 + yy*8, 7, 7);
        if(primmatrix[xx][yy])
          this.pnlHintergrund[xx][yy].setBackground(Color.RED);
        else
          this.pnlHintergrund[xx][yy].setBackground(Color.WHITE);
        pnlHintergrund[xx][yy].setToolTipText(yy*100+xx+1+"");
        cp.add(this.pnlHintergrund[xx][yy]);
      }
    }
    lblBeschriftung.setBounds(8, 8, 98, 24);
    lblBeschriftung.setText("Primzahlen ab:");
    lblBeschriftung.setFont(new Font("MS Sans Serif", Font.PLAIN, 13));
    cp.add(lblBeschriftung);
    nfdEingabefenster.setBounds(104, 8, 121, 24);
    nfdEingabefenster.setText("");
    cp.add(nfdEingabefenster);
    btnBerechne.setBounds(232, 8, 75, 25);
    btnBerechne.setText("Los!");
    btnBerechne.setMargin(new Insets(2, 2, 2, 2));
    btnBerechne.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent evt) {
        btnBerechne_ActionPerformed(evt);
      }
    });
    cp.add(btnBerechne);
    // Ende Komponenten

    setResizable(false);
    setVisible(true);
  }

  // Anfang Methoden
  public void btnBerechne_ActionPerformed(ActionEvent evt) {
    long bereich = Long.parseLong(this.nfdEingabefenster.getText());
    bereich = bereich / 10000 * 10000;
    this.nfdEingabefenster.setText(bereich+"");
    boolean[][] primmatrix = pzt.primzahlfeld(bereich);
    for(int xx = 0; xx < 100; xx++){
      for(int yy = 0; yy < 100; yy++){
        if(primmatrix[xx][yy])
          this.pnlHintergrund[xx][yy].setBackground(Color.RED);
        else
          this.pnlHintergrund[xx][yy].setBackground(Color.WHITE);
        this.pnlHintergrund[xx][yy].setToolTipText(yy*100+xx+1+bereich+"");
      }
    }
  }

  // Ende Methoden

}
