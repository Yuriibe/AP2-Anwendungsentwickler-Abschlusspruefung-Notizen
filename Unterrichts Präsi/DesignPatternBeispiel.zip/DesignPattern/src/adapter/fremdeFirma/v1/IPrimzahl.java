package adapter.fremdeFirma.v1;

public interface IPrimzahl {

	// entscheidet, ob der Parameter eine Primzahl ist
	public boolean isPrimzahl(long zahl);

	/*
	 * liefert ein zweidimensionales boolsches Feld mit den Ma�en 100x100
	 * zur�ck, wobei der jeweilige boolesche Wert [x][y] = 100*y+x + startwert
	 * repr�sentiert
	 */
	public boolean[][] primzahlfeld(long startwert);

}
