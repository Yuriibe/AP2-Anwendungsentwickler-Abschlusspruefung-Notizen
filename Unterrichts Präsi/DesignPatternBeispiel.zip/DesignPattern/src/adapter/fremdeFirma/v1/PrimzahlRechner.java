package adapter.fremdeFirma.v1;

public class PrimzahlRechner implements IPrimzahl {

	@Override
	public boolean isPrimzahl(long zahl) {
		zahl = Math.abs(zahl);
		if ( zahl < 2) return false;
		double sqrt = Math.sqrt(zahl);
		for(int teiler = 2; teiler <= sqrt; teiler++){
			if(zahl%teiler == 0) return false;
		}
		return true;
	}

	@Override
	public boolean[][] primzahlfeld(long startwert) {
		boolean[][] primzahlen = new boolean[100][100];
		for(int x = 0; x < 100; x++)
			for(int y= 0; y < 100; y++)
				primzahlen[x][y] = isPrimzahl(startwert + y*100+x);
		return primzahlen;
	}

}
