package adapter.fremdeFirma.v5411;

public class PrimzahlRechner implements IPrimzahl {

	@Override
	public boolean isPrimzahl(long zahl) {
		zahl = Math.abs(zahl);
		if ( zahl < 2) return false;
		double sqrt = Math.sqrt(zahl);
		for(int teiler = 2; teiler <= sqrt; teiler++){
			if(zahl%teiler == 0) return false;
		}
		return true;
	}

	@Override
	public boolean[] primzahlfeld(long startwert, int anzahlZahlen) {
		boolean[] primzahlen = new boolean[anzahlZahlen];
		for(int i = 0; i < anzahlZahlen; i++)
			primzahlen[i] = isPrimzahl(startwert + i);
			
		return primzahlen;
	}

}
