package adapter.fremdeFirma.v5411;

public interface IPrimzahl {

	// entscheidet, ob der Parameter eine Primzahl ist
	public boolean isPrimzahl(long zahl);

	/*
	 * gibt ein boolsches Feld zur�ck, beginnend mit der Zahl des Startwertes
	 * und mit der L�nge des zweiten Parameter
	 */
	public boolean[] primzahlfeld(long startwert, int anzahlZahlen);

	
	//und noch 5.000 weitere ganz tolle Methoden mit viel Funktionalit�t
}
